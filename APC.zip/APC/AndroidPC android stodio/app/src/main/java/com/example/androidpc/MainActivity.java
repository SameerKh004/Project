package com.example.androidpc;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Telephony;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Boolean isConnected=false;
    ListView mListView;
    List<String> Pcnamelist;
    List<String> pcipaddresslist;
    ArrayAdapter<String> adapter;
    static final int UdpServerPORT = 4445;
    UdpServerThread udpServerThread;
    private final static String TAG = MainActivity.class.getSimpleName();

    public static void sendMessageToServer(String message){

        try {
            Connect.objectOutputStream.writeObject(message);
            Connect.objectOutputStream.flush();
        } catch (Exception e) {
            e.printStackTrace();
            socketclose();
        }
    }
    public static void sendMessageToServer(int message){

        try {
            Connect.objectOutputStream.writeObject(message);
            Connect.objectOutputStream.flush();
        } catch (Exception e) {
            e.printStackTrace();
            socketclose();
        }
    }
    public static void socketclose() {
        if (Connect.clientSocket != null) {
            try {
                Connect.clientSocket.close();
                Connect.objectOutputStream.close();
                Connect.clientSocket = null;
            } catch(Exception e2) {
                e2.printStackTrace();
            }
        }
    }





    private void updateState( String  pc ,String ip){

        if(!Pcnamelist.contains(pc)){

            Pcnamelist.add(pc);
            pcipaddresslist.add(ip);

        }


        runOnUiThread(new Runnable() {
            @Override
            public void run() {


                adapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, Pcnamelist);

                mListView.setAdapter(adapter);

                mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, final int
                            position, long id) {

                        // it will get the position of selected item from the ListView

                        final int selected_item = position;

                        new AlertDialog.Builder(MainActivity.this).
                                setIcon(android.R.drawable.ic_delete)
                                .setTitle("Are you sure...")
                                .setMessage("connect to this pc..?")
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which)
                                    {
                                        isConnected=true;




                                        adapter.notifyDataSetChanged();
                                        Connect connect=new Connect(pcipaddresslist.get(position));
                                    }
                                })
                                .setNegativeButton("No" , null).show();

                        return true;
                    }
                });

            }
        });
    }







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy p=new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(p);
        Pcnamelist = new ArrayList<String>();
        pcipaddresslist=new ArrayList<String>();
        mListView = (ListView) findViewById(R.id.li);

        udpServerThread = new UdpServerThread(UdpServerPORT);
        udpServerThread.start();










    }


    private class UdpServerThread extends Thread{

        int serverPort;
        DatagramSocket socket;

        boolean running;

        public UdpServerThread(int serverPort) {
            super();
            this.serverPort = serverPort;
        }



        @Override
        public void run() {

            running = true;

            try {

                socket = new DatagramSocket(serverPort);

                Log.e(TAG, "UDP Server is running");

                while(running){
                    byte[] buf = new byte[5000];

                    // receive request
                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
                    socket.receive(packet);     //this code block the program flow
                    String text;

                    // send the response to the client at "address" and "port"
                    InetAddress address = packet.getAddress();
                    int port = packet.getPort();

                    text = new String(buf, 0, packet.getLength());

                    String[] lines = text.split("\\r?\\n");



                    updateState(text,packet.getAddress().toString().substring(1));



                }

                Log.e(TAG, "UDP Server ended");

            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if(socket != null){
                    socket.close();
                    Log.e(TAG, "socket.close()");
                }
            }
        }
    }

public void keyboard(){}
public void processlist(){}
public void mouse(View view){

    Intent i = new Intent(getApplicationContext(), Mouse.class);
    startActivity(i);
}
public void poweroption(View view){
    Intent i = new Intent(getApplicationContext(), PowerOption.class);
    startActivity(i);

}
    public void screenmonitor(View view){
        Intent i = new Intent(getApplicationContext(), ScreenMonitor.class);
        startActivity(i);

    }


}
