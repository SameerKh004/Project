package com.example.androidpc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Mouse extends AppCompatActivity {
    Button leftClickButton, rightClickButton;
    TextView touchPadTextView;
    int i;
    int initX, initY, disX, disY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mouse);



        leftClickButton = findViewById(R.id.leftClickButton);
        rightClickButton = findViewById(R.id.rightClickButton);
        touchPadTextView = findViewById(R.id.touchPadTextView);


        leftClickButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.sendMessageToServer("LEFT");
            }
        });

        rightClickButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.sendMessageToServer("RIGHT");
            }
        });

        touchPadTextView.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent touch) {
                if(touch.getAction() == MotionEvent.ACTION_DOWN){		// First touch, get the initial x and y positions
                    initX = (int) touch.getX();
                    initY = (int) touch.getY();
                    i = 0;
                }

                if(touch.getAction() == MotionEvent.ACTION_MOVE){ 		// Mouse Move, calculate the distance moved and send it to java app.
                    disX = (int) touch.getX() - initX;
                    disY= (int) touch.getY() - initY;
                    initX = (int) touch.getX();								// Update the initial positions
                    initY = (int) touch.getY();
                    MainActivity.sendMessageToServer("MOUSE_MOVE");
                    MainActivity.sendMessageToServer(disX);
                    MainActivity.sendMessageToServer(disY);
                    i = 1;
                }
                if(touch.getAction() == MotionEvent.ACTION_UP){			// Tap means left click
                    if(i == 0)
                        MainActivity.sendMessageToServer("LEFT");
                }
                return true;
            }
        });


    }
}
