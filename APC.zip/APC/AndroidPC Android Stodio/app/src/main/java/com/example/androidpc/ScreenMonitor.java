package com.example.androidpc;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import static android.widget.Toast.LENGTH_SHORT;

public class ScreenMonitor extends AppCompatActivity {

    private Socket imageTransferSocket;
    private DataInputStream inputStream;
    private Handler mHandler;
    static byte[] receivedByte;
    boolean messageFlag=false;
    Button left,right,connect;
    EditText ip,port;
    ImageView screen;
    RelativeLayout connector;
    FrameLayout screenPad;
    String serverIP,serverPort;
    static volatile int X;
    static volatile int Y;
    int startX,startY;
    long curTime;
    boolean inactivity=true;



    private final Handler handler = new Handler() {
        @Override
        public void handleMessage(Message message) {
            if(message.what == 2) {
                showText(message.obj.toString());
                connector.setVisibility(View.GONE);
                screenPad.setEnabled(true);
            }

            else if (message.what == 5){
                byte[] imageByte = (byte[]) message.obj;
                Log.d("handler", "called");
                Log.d("Handler: ", Integer.toString(imageByte.length));

                Bitmap bitmap = BitmapFactory.decodeByteArray(imageByte, 0, imageByte.length);
                screen.setImageBitmap(bitmap);
                //firstImage=false;
            }
        }
    };

    protected void onStop() {
        super.onStop();  // Always call the superclass method first
        MainActivity.sendMessageToServer("SCREENSTOP");

        inactivity=false;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_monitor);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        inputStream=Connect.inputStream;
        image(handler);


        try {
            getActionBar().hide();
        }catch (NullPointerException e) {

        }
        try {
            screenPad = (FrameLayout) findViewById(R.id.screenPad);
            screenPad.setEnabled(false);
            /**
             * Listener to handle Left Clicks
             */

            /**
             * Method to handle Right Click
             */



            screen = (ImageView) findViewById(R.id.imageView);
            /**
             * Callback Method to handle mouse pad drag and click events
             */

        }catch (Exception e) {
            showText(e.getMessage());
            Log.i("main",e.toString());
        }



    }

    private void showText(String x){
        Toast.makeText(this, x, LENGTH_SHORT).show();
    }

    public void image(final Handler mHandler){


        Thread thread = new Thread(){
            public void run(){
                MainActivity.sendMessageToServer("SCREEN");

                Message message = mHandler.obtainMessage();
                message.obj = "Hello from Image Transfer Thread";
                message.what = 1;
                mHandler.sendMessage(message);

                try {
                    while (inactivity) {

                        if (inputStream.available() > 0) {
                            int length = inputStream.readInt();
                            Log.d("Data Transfer: ", "Starting Data Transfer");
                            if (length > 0) {
                                receivedByte = new byte[length];
                                long time = System.currentTimeMillis();
                                inputStream.readFully(receivedByte);
                                if (time - System.currentTimeMillis() > 2000)
                                    Log.d("File Read: ", "stuck");
                                Log.d("Incoming", Integer.toString(receivedByte.length));
                                messageFlag = true;
                            }

                        }
                        if (messageFlag) {
                            Log.d("Message", "Entered Block");
                            Message msg = mHandler.obtainMessage();
                            msg.what = 5;
                            msg.obj = receivedByte;
                            mHandler.sendMessage(msg);
                            messageFlag = false;
                        }

                    }
                }catch (Exception e) {
                    e.printStackTrace();
                }
            }








        };

        thread.start();


    }
}
