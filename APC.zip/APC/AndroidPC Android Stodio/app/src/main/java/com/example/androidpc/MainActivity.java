package com.example.androidpc;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Telephony;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Boolean isConnected=false;
    ListView mListView;
    List<String> Pcnamelist;
    List<String> pcipaddresslist;
    List<String> password;
    ArrayAdapter<String> adapter;
    static final int UdpServerPORT = 4445;
    EditText input;
    private final static String TAG = MainActivity.class.getSimpleName();

    public static void sendMessageToServer(String message){

        try {
            Connect.objectOutputStream.writeObject(message);
            Connect.objectOutputStream.flush();
        } catch (Exception e) {
            e.printStackTrace();
            socketclose();
        }
    }
    public static void sendMessageToServer(int message){

        try {
            Connect.objectOutputStream.writeObject(message);
            Connect.objectOutputStream.flush();
        } catch (Exception e) {
            e.printStackTrace();
            socketclose();
        }
    }
    public static void socketclose() {
        if (Connect.clientSocket != null) {
            try {
                Connect.clientSocket.close();
                Connect.objectOutputStream.close();
                Connect.clientSocket = null;
            } catch(Exception e2) {
                e2.printStackTrace();
            }
        }
    }





    private void updateState( String  pc ,String ip){
        String[] lines = pc.split("\\r?\\n");


        if(Pcnamelist.contains(lines[0])){
            int index=Pcnamelist.indexOf(lines[0]);
            pcipaddresslist.set(index,ip);
            password.set(index,lines[1].trim());



        }
        else{
            Pcnamelist.add(lines[0]);
            pcipaddresslist.add(ip);
            password.add(lines[1].trim());

        }


        runOnUiThread(new Runnable() {
            @Override
            public void run() {


                adapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, Pcnamelist);

                mListView.setAdapter(adapter);

                mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, final int
                            position, long id) {


                      input = new EditText(MainActivity.this);
                        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);


                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("Enter PASSWORD")
                                .setView(input)
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                      String st=  input.getText().toString();
                                      Log.i("What is",password.get(position));

                                        if(input.getText().toString().equals(password.get(position))){
                                            isConnected=true;
                                            Connect connect=new Connect(pcipaddresslist.get(position));
                                            Toast.makeText(getApplicationContext(), "Connected to "+Pcnamelist.get(position), Toast.LENGTH_LONG).show();
                                        Pcnamelist.clear();
                                        password.clear();
                                        pcipaddresslist.clear();

                                        }
                                        else
                                            {

                                                Toast.makeText(getApplicationContext(), "Password Incorrect", Toast.LENGTH_LONG).show();



                                            }





                                        adapter.notifyDataSetChanged();



                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                }).show();

                        return true;
                    }
                });

            }
        });
    }







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy p=new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(p);
        Pcnamelist = new ArrayList<String>();
        pcipaddresslist=new ArrayList<String>();
        password=new ArrayList<String>();
        mListView = (ListView) findViewById(R.id.li);

       UdpServer(UdpServerPORT);











    }


    public void UdpServer(final int serverPortt){


        new Thread(){

            int serverPort=serverPortt;
            DatagramSocket socket;
            boolean running;
            public void run() {

                running = true;

                try {

                    socket = new DatagramSocket(serverPort);

                    Log.e(TAG, "UDP Server is running");

                    while(running){
                        byte[] buf = new byte[5000];

                        // receive request
                        DatagramPacket packet = new DatagramPacket(buf, buf.length);
                        socket.receive(packet);     //this code block the program flow
                        String text;

                        // send the response to the client at "address" and "port"
                        InetAddress address = packet.getAddress();
                        int port = packet.getPort();

                        text = new String(buf, 0, packet.getLength());





                        updateState(text,packet.getAddress().toString().substring(1));



                    }

                    Log.e(TAG, "UDP Server ended");

                } catch (SocketException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if(socket != null){
                        socket.close();
                        Log.e(TAG, "socket.close()");
                    }
                }
            }

        }.start();

    }




public void keyboard(View view){
        if(isConnected){
            Intent i = new Intent(getApplicationContext(), Keyboard.class);
             startActivity(i);
        }
        else
            Toast.makeText(getApplicationContext(), "Not connected to pc", Toast.LENGTH_SHORT).show();

}
public void processlist(View view){
    if(isConnected){
        Intent i = new Intent(getApplicationContext(), ProcessControl.class);

        startActivity(i);
    }
    else
        Toast.makeText(getApplicationContext(), "Not connected to pc", Toast.LENGTH_SHORT).show();
}
public void mouse(View view){
    if(isConnected){
        Intent i = new Intent(getApplicationContext(), Mouse.class);
        startActivity(i);
    }
    else
        Toast.makeText(getApplicationContext(), "Not connected to pc", Toast.LENGTH_SHORT).show();


}
public void poweroption(View view){
    if(isConnected){
        Intent i = new Intent(getApplicationContext(), PowerOption.class);
        startActivity(i);
    }
    else
        Toast.makeText(getApplicationContext(), "Not connected to pc", Toast.LENGTH_SHORT).show();


}
    public void screenmonitor(View view){
        if(isConnected){
            Intent i = new Intent(getApplicationContext(), ScreenMonitor.class);
            startActivity(i);
        }
        else
            Toast.makeText(getApplicationContext(), "Not connected to pc", Toast.LENGTH_SHORT).show();


    }



}
