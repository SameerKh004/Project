package com.example.androidpc;
import android.net.InetAddresses;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

public class Connect {
     int port =3000;
    public  Socket clientSocket = null;
    public  ObjectInputStream objectInputStream = null;
    public  ObjectOutputStream objectOutputStream = null;
    public  InetAddress server= null;
    public   Socket socketImage =null;
    public   DataInputStream inputStream;
    public   boolean connected=false;






    Connect(final String ip) {

        Thread thread = new Thread(){
            public void run(){


                try {
                    clientSocket = new Socket();
                    SocketAddress socketAddress = new InetSocketAddress(ip, 3000);
                     socketImage = new Socket(ip, 3001);
                     server = InetAddress.getByName(ip);
                    clientSocket.connect(socketAddress, 3000);
                    objectInputStream = new ObjectInputStream(clientSocket.getInputStream());
                    objectOutputStream = new ObjectOutputStream(clientSocket.getOutputStream());
                    inputStream = new DataInputStream(socketImage.getInputStream());
                    connected=true;
                }
                catch (IOException e) {
                    e.printStackTrace();
                }

            }
        };

        thread.start();



    }







}
