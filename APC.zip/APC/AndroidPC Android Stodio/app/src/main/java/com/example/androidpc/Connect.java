package com.example.androidpc;
import android.net.InetAddresses;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

public class Connect {
     int port =3000;
    public static Socket clientSocket = null;
    public static ObjectInputStream objectInputStream = null;
    public static ObjectOutputStream objectOutputStream = null;
    public static InetAddress server= null;
    public  static Socket socketImage =null;
    public  static DataInputStream inputStream;
    public  static boolean connected=false;






    Connect(final String ip) {

        Thread thread = new Thread(){
            public void run(){


                try {
                    clientSocket = new Socket();
                    SocketAddress socketAddress = new InetSocketAddress(ip, 3000);
                     socketImage = new Socket(ip, 3001);
                     server = InetAddress.getByName(ip);
                    clientSocket.connect(socketAddress, 3000);
                    objectInputStream = new ObjectInputStream(clientSocket.getInputStream());
                    objectOutputStream = new ObjectOutputStream(clientSocket.getOutputStream());
                    inputStream = new DataInputStream(socketImage.getInputStream());
                    connected=true;
                }
                catch (IOException e) {
                    e.printStackTrace();
                }

            }
        };

        thread.start();



    }







}
