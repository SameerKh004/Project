package com.example.androidpc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.KeyEvent;
import android.widget.Button;
import android.widget.Toast;

public class Keyboard extends AppCompatActivity {
    Button Lshiftbutton,Rshiftbutton ,LCTRL,RCTRL,LALT,RALT,LWIN,RWIN;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_keyboard);
        Rshiftbutton=findViewById(R.id.shiftr);
        Lshiftbutton=findViewById(R.id.shiftl);
        LCTRL=findViewById(R.id.lctrl);
        RCTRL=findViewById(R.id.rctrl);
        LALT=findViewById(R.id.lalt);
        RALT=findViewById(R.id.ralt);
        LWIN=findViewById(R.id.lwin);
        RWIN=findViewById(R.id.rwin);







        Rshiftbutton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("SHIFT");
                        MainActivity.sendMessageToServer("PRESS");

                        break;
                    }
                    case MotionEvent.ACTION_UP: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("SHIFT");
                        MainActivity.sendMessageToServer("RELEASE");

                        break;
                    }
                }
                return false;
            }
        });



        Lshiftbutton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("SHIFT");
                        MainActivity.sendMessageToServer("PRESS");

                        break;
                    }
                    case MotionEvent.ACTION_UP: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("SHIFT");
                        MainActivity.sendMessageToServer("RELEASE");

                        break;
                    }
                }
                return false;
            }
        });




        LCTRL.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("CTRL");
                        MainActivity.sendMessageToServer("PRESS");

                        break;
                    }
                    case MotionEvent.ACTION_UP: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("CTRL");
                        MainActivity.sendMessageToServer("RELEASE");

                        break;
                    }
                }
                return false;
            }
        });




        RCTRL.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("CTRL");
                        MainActivity.sendMessageToServer("PRESS");

                        break;
                    }
                    case MotionEvent.ACTION_UP: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("CTRL");
                        MainActivity.sendMessageToServer("RELEASE");

                        break;
                    }
                }
                return false;
            }
        });




        LALT.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("ALT");
                        MainActivity.sendMessageToServer("PRESS");

                        break;
                    }
                    case MotionEvent.ACTION_UP: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("ALT");
                        MainActivity.sendMessageToServer("RELEASE");

                        break;
                    }
                }
                return false;
            }
        });





        RALT.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("ALT");
                        MainActivity.sendMessageToServer("PRESS");

                        break;
                    }
                    case MotionEvent.ACTION_UP: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("ALT");
                        MainActivity.sendMessageToServer("RELEASE");

                        break;
                    }
                }
                return false;
            }
        });




        LWIN.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("WIN");
                        MainActivity.sendMessageToServer("PRESS");

                        break;
                    }
                    case MotionEvent.ACTION_UP: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("WIN");
                        MainActivity.sendMessageToServer("RELEASE");

                        break;
                    }
                }
                return false;
            }
        });





        RWIN.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("WIN");
                        MainActivity.sendMessageToServer("PRESS");

                        break;
                    }
                    case MotionEvent.ACTION_UP: {
                        MainActivity.sendMessageToServer("KEYBOARD");
                        MainActivity.sendMessageToServer("WIN");
                        MainActivity.sendMessageToServer("RELEASE");

                        break;
                    }
                }
                return false;
            }
        });





    }
    public void onClick(View v) {
        String name = v.getResources().getResourceEntryName(v.getId());
        MainActivity.sendMessageToServer("KEYBOARD");
        MainActivity.sendMessageToServer("WRITE");
        MainActivity.sendMessageToServer(name.trim());
    }




    }

