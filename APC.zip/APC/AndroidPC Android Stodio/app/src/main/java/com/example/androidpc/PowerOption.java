package com.example.androidpc;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class PowerOption extends AppCompatActivity  {

    Button shutdownButton, restartButton, sleepButton, lockButton;
    DialogInterface.OnClickListener dialogClickListener;
    AlertDialog.Builder builder;
    String action;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_power_option);


        sleepButton=findViewById(R.id.sleepButton);
        restartButton=findViewById(R.id.restartButton);
        lockButton=findViewById(R.id.lockButton);
        shutdownButton=findViewById(R.id.shutdownButton);


        dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch(which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        sendActionToServer(action);
                        dialog.dismiss();
                        break;
                    case DialogInterface.BUTTON_NEGATIVE:
                        dialog.dismiss();
                        break;
                }

            }
        };


        builder = new AlertDialog.Builder(this);




    }
    public void onClick(View v) {
        int id = v.getId();
        switch(id) {
            case R.id.shutdownButton:
                action = "Shutdown_PC";
                break;
            case R.id.restartButton:
                action = "Restart_PC";

                break;
            case R.id.sleepButton:
                action = "Sleep_PC";
                break;
            case R.id.lockButton:
                action = "Lock_PC";
                break;
        }
        showConfirmDialog();

    }
    private void showConfirmDialog() {
        builder.setTitle(action)
                .setMessage("Are you sure?")
                .setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener)
                .show();
    }
    private void sendActionToServer(String action) {

        MainActivity.sendMessageToServer("POWER");
        MainActivity.sendMessageToServer(action);
    }
}
