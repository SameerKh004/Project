package com.example.androidpc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Mouse extends AppCompatActivity {
    Button leftClickButton, rightClickButton;
    TextView touchPadTextView,scrollpadTextView;
    int initmouseX, initmouseY, dismouseX, dismouseY,initscrollY,disscrollY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mouse);



        leftClickButton = findViewById(R.id.leftClickButton);
        rightClickButton = findViewById(R.id.rightClickButton);
        touchPadTextView = findViewById(R.id.touchPadTextView);
        scrollpadTextView= findViewById(R.id.scrollbar);


        leftClickButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        MainActivity.sendMessageToServer("LEFT");
                        MainActivity.sendMessageToServer("PRESS");

                        break;
                    }
                    case MotionEvent.ACTION_UP: {
                        MainActivity.sendMessageToServer("LEFT");
                        MainActivity.sendMessageToServer("RELEASE");

                        break;
                    }
                }
                return false;
            }
        });


        rightClickButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        MainActivity.sendMessageToServer("RIGHT");
                        MainActivity.sendMessageToServer("PRESS");

                        break;
                    }
                    case MotionEvent.ACTION_UP: {
                        MainActivity.sendMessageToServer("RIGHT");
                        MainActivity.sendMessageToServer("RELEASE");

                        break;
                    }
                }
                return false;
            }
        });

        touchPadTextView.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent touch) {
                if(touch.getAction() == MotionEvent.ACTION_DOWN){		// First touch, get the initial x and y positions
                    initmouseX = (int) touch.getX();
                    initmouseY = (int) touch.getY();

                }

                if(touch.getAction() == MotionEvent.ACTION_MOVE){ 		// Mouse Move, calculate the distance moved and send it to java app.
                    dismouseX = (int) touch.getX() - initmouseX;
                    dismouseY= (int) touch.getY() - initmouseY;
                    initmouseX = (int) touch.getX();								// Update the initial positions
                    initmouseY = (int) touch.getY();
                    MainActivity.sendMessageToServer("MOUSE_MOVE");
                    MainActivity.sendMessageToServer(dismouseX);
                    MainActivity.sendMessageToServer(dismouseY);
                }
                return true;
            }
        });




        scrollpadTextView.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent touch) {
                if(touch.getAction() == MotionEvent.ACTION_DOWN){		// First touch, get the initial  y position
                    initscrollY = (int) touch.getY();

                }

                if(touch.getAction() == MotionEvent.ACTION_MOVE){ 		// Mouse Move, calculate the distance moved and send it to java app.
                    disscrollY= (int) touch.getY() - initscrollY;
                    initscrollY = (int) touch.getY();							// Update the initial positions
                    MainActivity.sendMessageToServer("MOUSE_SCROLL");
                    MainActivity.sendMessageToServer(disscrollY/10);
                }
                return true;
            }
        });


    }
}
