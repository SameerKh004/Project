package com.example.androidpc;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

public class ProcessControl extends AppCompatActivity {

    ListView mListView;
    List<String> processlist;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_process_control);
        processlist = new ArrayList<String>();

        mListView = (ListView) findViewById(R.id.processlistdisplayer);




        getprocesses();



    }

    private void updateState(String  processes ){
        String[] lines = processes.split("\\r?\\n");
        processlist.clear();

        for(int i=2;i<lines.length;i++)
        {
            processlist.add(lines[i]);

        }





        runOnUiThread(new Runnable() {
            @Override
            public void run() {


                adapter = new ArrayAdapter(ProcessControl.this, android.R.layout.simple_list_item_1, processlist);

                mListView.setAdapter(adapter);

                mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, final int
                            position, long id) {

                        // it will get the position of selected item from the ListView

                        final int selected_item = position;

                        new AlertDialog.Builder(ProcessControl.this).
                                setIcon(android.R.drawable.ic_delete)
                                .setTitle("Are you sure...")
                                .setMessage("END  "+processlist.get(position)+"?")
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which)
                                    {




                                        adapter.notifyDataSetChanged();
                                        MainActivity.sendMessageToServer("Processend");
                                        MainActivity.sendMessageToServer((String)processlist.get(position));
                                        getprocesses();


                                    }
                                })
                                .setNegativeButton("No" , null).show();

                        return true;
                    }
                });

            }
        });
    }

    public void getprocesses(){
        MainActivity.sendMessageToServer("Process");



        new Thread(){
            @Override
            public void run() {
                ObjectInputStream objectInputStream =MainActivity.connect.objectInputStream;



                try {




                    String text;



                    text = (String) objectInputStream.readObject();





                    updateState(text);


                } catch (Exception e) {
                    e.printStackTrace();
                }

            }


        }.start();
    }



}
