package com.example.androidpc;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

public class ProcessControl extends AppCompatActivity {
    private final static String TAG = MainActivity.class.getSimpleName();
    Boolean isConnected=false;
    ListView mListView;
    List<String> Pcnamelist;
    List<String> pcipaddresslist;
    ArrayAdapter<String> adapter;
    static final int UdpServerPORT = 4445;
    UdpServerThread udpServerThread  = new UdpServerThread();;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_process_control);
        Pcnamelist = new ArrayList<String>();
        pcipaddresslist=new ArrayList<String>();

        mListView = (ListView) findViewById(R.id.processlistdisplayer);




        udpServerThread.start();
        Log.i("Process Controll","Started now");
        MainActivity.sendMessageToServer("Process");


    }

    private void updateState(String  pc ){
        String[] lines = pc.split("\\r?\\n");
        Pcnamelist.clear();
        Log.i("Process Controll","Started now UI thread");

        for(int i=2;i<lines.length;i++)
        {
            Pcnamelist.add(lines[i]);

        }





        runOnUiThread(new Runnable() {
            @Override
            public void run() {


                adapter = new ArrayAdapter(ProcessControl.this, android.R.layout.simple_list_item_1, Pcnamelist);

                mListView.setAdapter(adapter);

                mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, final int
                            position, long id) {

                        // it will get the position of selected item from the ListView

                        final int selected_item = position;

                        new AlertDialog.Builder(ProcessControl.this).
                                setIcon(android.R.drawable.ic_delete)
                                .setTitle("Are you sure...")
                                .setMessage("END ..?"+Pcnamelist.get(position))
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which)
                                    {
                                        isConnected=true;




                                        adapter.notifyDataSetChanged();
                                        MainActivity.sendMessageToServer("Processend");
                                        MainActivity.sendMessageToServer((String)Pcnamelist.get(position));


                                    }
                                })
                                .setNegativeButton("No" , null).show();

                        return true;
                    }
                });

            }
        });
    }

    private class UdpServerThread extends Thread{

        ObjectInputStream objectInputStream = null;

        int serverPort;
        DatagramSocket socket;

        boolean running;

        public UdpServerThread() {
            super();
            objectInputStream=Connect.objectInputStream;
        }



        @Override
        public void run() {



            try {




                    String text;



                    text = (String) objectInputStream.readObject();





                    updateState(text);



                udpServerThread.stop();

                Log.e(TAG, "UDP Server ended");

            } catch (Exception e) {
                e.printStackTrace();
            }
              finally {
                if(socket != null){
                    socket.close();
                    Log.e(TAG, "socket.close()");
                }
            }
        }
    }

}
