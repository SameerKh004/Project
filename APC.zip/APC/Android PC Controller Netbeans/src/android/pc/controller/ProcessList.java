/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package android.pc.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sameer Zalmay
 */
public class ProcessList {
    
public String getprocess(){
    String pid;
            String sa="";

        try{
            
            Process p = Runtime.getRuntime().exec
    ("tasklist.exe /nh");
//            Process p =Runtime.getRuntime().exec("tasklist");
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
        while ((pid = br.readLine()) != null)
		{
                    if (!pid.trim().equals("")) {
                        sa=sa+"\n"+pid.substring(0, pid.indexOf("  "));
                
                    }
        }
        
        }
        catch(Exception e){
        
            
        }
        
        
        return sa;
        
        
        
} 
public void endprocess(String process_name){
 String KILL = "taskkill /F /IM ";
    
    try {
        Runtime.getRuntime().exec(KILL+process_name);
    } catch (IOException ex) {
        Logger.getLogger(ProcessList.class.getName()).log(Level.SEVERE, null, ex);
    }


}
    
}
