/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package android.pc.controller;

import java.awt.MouseInfo;
import java.awt.Point;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sameer Z
 */
public class Server {

    public static ServerSocket serverSocket = null;
    public static Socket clientSocket = null;
    public static InputStream is = null;
    public static OutputStream os = null;
    public static ObjectOutputStream objectOutputStream = null;
    public static ObjectInputStream objectInputStream = null;
    public static Screen sc;
   public static ServerSocket serverSocketImage=null;
   public static Socket socketImage = null;
   public static boolean inactivity=true;
   

    Server(int port) {

        Thread thread = new Thread() {
            public void run() {
                try {
                    serverSocket = new ServerSocket(port);
                    serverSocketImage = new ServerSocket(port + 1);
                    startServer(port);

                } catch (IOException ex) {
                    Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        };

        thread.start();

    }

    public void startServer(int port) {
        String message;
        try {
            clientSocket = serverSocket.accept();
            socketImage=serverSocketImage.accept();
            APCC.isconnected=true;
             sc=new Screen();
            APCC.info.setText("Connected");
            APCC.resetconnectionbtn.setEnabled(true);

            MouseKey control = new MouseKey();

            is = clientSocket.getInputStream();
            os = clientSocket.getOutputStream();
            objectOutputStream = new ObjectOutputStream(os);
            objectInputStream = new ObjectInputStream(is);

            while (true) {
                try {
                    message = (String) objectInputStream.readObject();
                    if (message != null) {
                        switch (message) {

                            case "KEYBOARD":
                                switch((String) objectInputStream.readObject()){
                                case"SHIFT":
                                    control.shift((String) objectInputStream.readObject());
                                    break;
                                case"ALT":
                                    control.alt((String) objectInputStream.readObject());
                                    break;
                                case"CTRL":
                                    control.ctrl((String) objectInputStream.readObject());
                                    break;
                                case"WIN":
                                    control.win((String) objectInputStream.readObject());
                                    break;
                                case"WRITE":
                                    control.type((String) objectInputStream.readObject());
                                    break;
                                
                                
                                
                                }
                              
                                
                                break;
                            case "LEFT":
                                
                                control.LeftClick();
                                break;
                            case "RIGHT":
                                control.RightClick();
                                break;
                            case "MOUSE_MOVE":
                                int x = (int) objectInputStream.readObject();
                                int y = (int) objectInputStream.readObject();
                                Point p = MouseInfo.getPointerInfo().getLocation(); //current  position
                                float X = p.x;
                                float Y = p.y;
                                control.Move((int) (X + x), (int) (Y + y));
                                break;
                            case "Process":
                                objectOutputStream.writeObject(new ProcessList().getprocess());
                                System.out.println(message);
                                objectOutputStream.flush();
                                break;
                                 case "Processend":
                                     new ProcessList().endprocess((String)objectInputStream.readObject());

                                break;
                               
                            case"POWER":
                                new poweroption().power((String)objectInputStream.readObject());
                                break;
                            case"SCREEN":
                                if(sc.isAlive())
                                {
                                sc.resume();
                                    System.out.println("resume");
                                
                                }
                                else
                                { sc.start();
                                System.out.println("started");
                                }break;
                            case"SCREENSTOP":
                                sc.suspend(); 
                                break;
                             case"EXIT":
                                new APCC().resetconnection();
                                break;
                                
                            

                        }
                    }
                    else {
                        connectionClosed();
                        break;
                    }
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        } catch (Exception e) {
           connectionClosed();
           
         
           }

    }

    static void connectionClosed() {
        try {
            objectInputStream.close();
            clientSocket.close();
            serverSocket.close();
            serverSocketImage.close();
            is.close();
            os.close();
            objectOutputStream.close();
        } catch (Exception e) {
            APCC.info.setText("Error in closing server");
        }
    }

}
