/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package android.pc.controller;

/**
 *
 * @author Sameer Zalmay
 */
public class poweroption {
    
    public  void power(String s){
    switch(s){
    case"Shutdown_PC":
        shutdown();
    break;
    case"Restart_PC":
        restart();
    break;
    case"Sleep_PC":
        sleep();
    break;
    case"Lock_PC":
        lock();
    break;
    
    
    }
    
    
    }
    
    public void shutdown(){
        
         try {
        Runtime.getRuntime().exec("cmd /c shutdown -s");
            
        } catch (Exception e) {
          
        }
        
    
    }
    public void sleep(){
  
   try {
        Runtime.getRuntime().exec("powercfg -hibernate off");
        Runtime.getRuntime().exec("rundll32.exe powrprof.dll,SetSuspendState 0,1,0");
        
        
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public void restart(){
    
    
     try {
        Runtime.getRuntime().exec("cmd /c shutdown -r");
            
        } catch (Exception e) {
          System.out.println(e);
        }
    
    }
    public void lock(){
    try {
        Runtime.getRuntime().exec("rundll32.exe user32.dll,LockWorkStation");
           
        }
    catch (Exception e) {
            System.out.println(e);
        }
    }
    
}
