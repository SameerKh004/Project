/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package android.pc.controller;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import static java.awt.event.KeyEvent.*;


/**
 *
 * @author Sameer Z
 */
public class MouseKey {

    Robot robot;

    public MouseKey() {
        try {
            robot = new Robot();
        } catch (Exception e) {
            APCC.info.setText("Error in Robot");
        }
    }

    public void press(int keyCodes) {
     
            robot.keyPress(keyCodes);
        
        robot.delay(10);

            robot.keyRelease(keyCodes);
        
    }
    public void alt(String command){
   switch(command){
        case"PRESS":
            robot.keyPress(VK_ALT);
            break;
        case"RELEASE":
            robot.keyRelease(VK_ALT);
            break;
    
    }
    
    }
    public void ctrl(String command){
   switch(command){
        case"PRESS":
            robot.keyPress(VK_CONTROL);
            break;
        case"RELEASE":
            robot.keyRelease(VK_CONTROL);
            break;
    
    }
    
    }
    public void shift(String command){
   switch(command){
        case"PRESS":
            robot.keyPress(VK_SHIFT);
            break;
        case"RELEASE":
            robot.keyRelease(VK_SHIFT);
            break;
    
    }
    }
    public void win(String command){
    
    switch(command){
        case"PRESS":
            robot.keyPress(VK_WINDOWS);
            break;
        case"RELEASE":
            robot.keyRelease(VK_WINDOWS);
            break;
    
    }
    
    }

    public void type(String character) {
        String chat=character.trim();
        switch (chat) {
            case "a":
                press(VK_A);
                break;
            case "b":
                press(VK_B);
                break;
            case "c":
                press(VK_C);
                break;
            case "d":
                press(VK_D);
                break;
            case "e":
                press(VK_E);
                break;
            case "f":
                press(VK_F);
                break;
            case "g":
                press(VK_G);
                break;
            case "h":
                press(VK_H);
                break;
            case "i":
                press(VK_I);
                break;
            case "j":
                press(VK_J);
                break;
            case "k":
                press(VK_K);
                break;
            case "l":
                press(VK_L);
                break;
            case "m":
                press(VK_M);
                break;
            case "n":
                press(VK_N);
                break;
            case "o":
                press(VK_O);
                break;
            case "p":
                press(VK_P);
                break;
            case "q":
                press(VK_Q);
                break;
            case "r":
                press(VK_R);
                break;
            case "s":
                press(VK_S);
                break;
            case "t":
                press(VK_T);
                break;
            case "u":
                press(VK_U);
                break;
            case "v":
                press(VK_V);
                break;
            case "w":
                press(VK_W);
                break;
            case "x":
                press(VK_X);
                break;
            case "y":
                press(VK_Y);
                break;
            case "z":
                press(VK_Z);
                break;
           
            case "BACK_QUOTE":
                press(VK_BACK_QUOTE);
                break;
            case "zero":
                press(VK_0);
                break;
            case "one":
                press(VK_1);
                break;
            case "two":
                press(VK_2);
                break;
            case "three":
                press(VK_3);
                break;
            case "four":
                press(VK_4);
                break;
            case "five":
                press(VK_5);
                break;
            case "six":
                press(VK_6);
                break;
            case "seven":
                press(VK_7);
                break;
            case "eight":
                press(VK_8);
                break;
            case "nine":
                press(VK_9);
                break;
            case "MINUS":
                press(VK_MINUS);
                break;
            case "EQUALS":
                press(VK_EQUALS);
                break;
            case "TAB":
                press(VK_TAB);
                break;
            case "ENTER":
                press(VK_ENTER);
                break;
            case "OPEN_BRACKET":
                press(VK_OPEN_BRACKET);
                break;
            case "CLOSE_BRACKET":
                press(VK_CLOSE_BRACKET);
                break;
            case "BACK_SLASH":
                press(VK_BACK_SLASH);
                break;
            case "SEMICOLON":
                press(VK_SEMICOLON);
                break;
            case "QUOTE":
                press(VK_QUOTE);
                break;
            case "COMMA":
                press(VK_COMMA);
                break;

            case "PERIOD":
                press(VK_PERIOD);
                break;
            case "SLASH":
                press(VK_SLASH);
                break;
            case "SPACE":
                press(VK_SPACE);
                break;
            case "BACKSPACE":
               
                press(VK_BACK_SPACE);
                break;
            case "CAPSLOCK":
                press(VK_CAPS_LOCK);
                break;
            case "ESC":
       
                press(VK_ESCAPE);
                break;
                
            case "DEL":
               
                press(VK_DELETE);
                break;
                
                
            case "UP":
       
                press(VK_UP);
                break;
                
                
            case "DOWN":
                press(VK_DOWN);
                break;
                
                
            case "RIGHT":
                press(VK_RIGHT);
                break;
                
                
            case "LEFT":
                press(VK_LEFT);
                break;
                
                
        }
    }

    public void type(int keyCode) {
        robot.keyPress(keyCode);
        robot.delay(10);
        robot.keyRelease(keyCode);
    }

    public void LeftClick(String state) {
        switch(state){
            case"PRESS":
                robot.mousePress(InputEvent.BUTTON1_MASK);
                break;
            case"RELEASE":
                robot.mouseRelease(InputEvent.BUTTON1_MASK);
                break;
        }
        
  
        
    }

    public void RightClick(String state) {
        switch(state){
            case"PRESS":
                robot.mousePress(InputEvent.BUTTON3_MASK);
                break;
            case"RELEASE":
                robot.mouseRelease(InputEvent.BUTTON3_MASK);
                break;
        }
        
        
    }

    public void Move(int x, int y) {
        robot.mouseMove(x, y);
        
    }
      public void MoveScroll( int y) {
        robot.mouseWheel(y);
        
    }
    
}
